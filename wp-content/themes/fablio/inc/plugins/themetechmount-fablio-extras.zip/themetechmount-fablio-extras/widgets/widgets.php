<?php

// Contact Widget
require TMTE_DIR . '/widgets/contact-widget.php';

// Recent Posts Widget
require TMTE_DIR . '/widgets/recent-posts-widget.php';

// Flicker Widget
require TMTE_DIR . '/widgets/flicker-widget.php';

// Category/Group List Widget
require TMTE_DIR . '/widgets/category-list.php';

// All Post List Widget
require TMTE_DIR . '/widgets/all-posts-list.php';

