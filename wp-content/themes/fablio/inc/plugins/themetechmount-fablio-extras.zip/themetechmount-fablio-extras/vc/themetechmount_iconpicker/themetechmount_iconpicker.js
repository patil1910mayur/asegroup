// This function is available in admin-custom.js file. This function is also used in CodeStar icon picker developed by ThemeTechMount
themetechmount_icon_picker();
